package com.wishers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WishersApplication {
  public static void main(String[] args) {
    SpringApplication.run(WishersApplication.class, args);
  }
}
